/** Automatically generated file. DO NOT MODIFY */
package com.app.pictolike;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}