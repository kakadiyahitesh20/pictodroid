package com.app.pictolike.data;

public class PictoFile {
	public String username;
	public String filename;
	public String dateCreated;
	public String locationCreated;
}
