package com.app.pictolike.data;

import java.util.ArrayList;

public class Constant {
	public static ArrayList<String> homeScreenImageArray=new ArrayList<String>();
}
