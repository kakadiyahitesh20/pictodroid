package com.app.pictolike.data;

public class MyPeople {
	public String name;
	public String email;
	public String password;
	public String birthday;
	public String gender; 
	//public String deviceId; 
}
