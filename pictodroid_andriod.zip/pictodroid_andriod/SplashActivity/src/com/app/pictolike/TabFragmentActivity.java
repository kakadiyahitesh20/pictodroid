package com.app.pictolike;

import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.app.Activity;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;

import com.app.pictolike.data.Constant;
import com.app.pictolike.mysql.GetHomeScreenImageCommand;

public class TabFragmentActivity extends Activity {

	ActionBar.Tab homeTab; //, settingsTab

	HomePageActivity fragmentHome = new HomePageActivity(TabFragmentActivity.this);
	//SettingsScreenActivity fragmentSettings = new SettingsScreenActivity();
	ActionBar actionBar;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		actionBar = getActionBar();
		actionBar.setStackedBackgroundDrawable(getResources().getDrawable(
				R.drawable.top_bar));
		
		Constant.homeScreenImageArray.clear();
		new getHomeScreenImageData().execute();
		
		// Hide Actionbar Icon
		actionBar.setDisplayShowHomeEnabled(false);

		// Hide Actionbar Title
		actionBar.setDisplayShowTitleEnabled(false);

		// Create Actionbar Tabs
		actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

		// Set Tab Icon and Titles
		homeTab = actionBar.newTab().setIcon(R.drawable.ic_home_tab);
		//settingsTab = actionBar.newTab().setIcon(R.drawable.ic_settings_tab);

		// Set Tab Listeners
		homeTab.setTabListener(new TabListener(fragmentHome));
		//settingsTab.setTabListener(new TabListener(fragmentSettings));
		
		// Add tabs to actionbar
		
		//actionBar.addTab(settingsTab);
	}

	
	class getHomeScreenImageData extends AsyncTask<String, String, String>
	{
		public ProgressDialog dialog;
		@Override
        protected void onPreExecute() {
            super.onPreExecute();	            
            dialog = new ProgressDialog(TabFragmentActivity.this);
            dialog.setMessage("Retriving Data..");
            dialog.setCancelable(true);
            dialog.setIndeterminate(true);
            dialog.show();
        }
		@Override
		protected String doInBackground(String... params) {
			try 
			{				
				//Reader reader = new InputStreamReader(new URL(MySQLConnect.LINK_GETPICTODATA).openStream());
				//Gson gson=new GsonBuilder().create();
				//pictoFile=gson.fromJson(reader, PictoFile.class);	
				GetHomeScreenImageCommand getpictocmd=new GetHomeScreenImageCommand();
				getpictocmd.command();				
				//System.out.println(pictoFileData);				
			} 
			catch (Exception e) 
			{				
				e.printStackTrace();
			}
			return null;
		}
		@Override
		protected void onPostExecute(String Result)
		{
			super.onPostExecute(Result);			
			try
			{
				dialog.dismiss();	
				actionBar.addTab(homeTab);
				//actionBar.addTab(saveTab);
				//actionBar.addTab(profileTab);
				
			}
			catch(Exception e)
			{
				System.out.println("Error " + e);
			}
		}		
	}
	
	
	public class TabListener implements ActionBar.TabListener {

		android.app.Fragment fragment;

		public TabListener(android.app.Fragment fragment) {
			// TODO Auto-generated constructor stub
			this.fragment = fragment;
		}

		@Override
		public void onTabSelected(Tab tab, FragmentTransaction ft) {
			// TODO Auto-generated method stub
			ft.replace(R.id.fragment_container, fragment);
		}

		@Override
		public void onTabUnselected(Tab tab, FragmentTransaction ft) {
			// TODO Auto-generated method stub
			ft.remove(fragment);
		}

		@Override
		public void onTabReselected(Tab tab, FragmentTransaction ft) {
			// TODO Auto-generated method stub

		}
	}
}
