-- phpMyAdmin SQL Dump
-- version 4.0.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 14, 2014 at 01:36 PM
-- Server version: 5.5.32-cll-lve
-- PHP Version: 5.3.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `PictoLike`
--

-- --------------------------------------------------------

--
-- Table structure for table `Picto`
--

CREATE TABLE IF NOT EXISTS `Picto` (
  `username` varchar(20) DEFAULT NULL,
  `filename` varchar(20) DEFAULT NULL,
  `datecreated` varchar(20) DEFAULT NULL,
  `locationcreated` varchar(20) DEFAULT NULL,
  `noOfLikes` int(30) unsigned DEFAULT NULL,
  `noOfViews` int(30) unsigned DEFAULT NULL,
  `Text_Added` varchar(50) NOT NULL,
  `firstPictoLikePicture` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Picto`
--

INSERT INTO `Picto` (`username`, `filename`, `datecreated`, `locationcreated`, `noOfLikes`, `noOfViews`, `Text_Added`, `firstPictoLikePicture`) VALUES
('arslanshl@gmail.com', 'hello.php', NULL, NULL, NULL, NULL, '', ''),
('', '', NULL, NULL, NULL, NULL, '', ''),
('', '', NULL, NULL, NULL, NULL, '', ''),
('test1', '20140701_202009', '', '', NULL, NULL, '', ''),
('test1', '20140701_204651', '', '', NULL, NULL, '', ''),
('test1', '20140701_205622', '', '', NULL, NULL, '', ''),
('test1', '20140701_210424', '', '', NULL, NULL, '', ''),
('test1', '20140701_211049', '', '', NULL, NULL, '', ''),
('test1', '20140701_212039', '', '', NULL, NULL, '', ''),
('test1', '20140701_213506', '', '', NULL, NULL, '', ''),
('test1', '20140701_213819', '', '', NULL, NULL, '', ''),
('test1', '20140701_214352', '', '', NULL, NULL, '', ''),
('test1', '20140701_215714', '', '', NULL, NULL, '', ''),
('test1', '20140701_220038', '', '', NULL, NULL, '', ''),
('test1', '20140701_220657', '', '', NULL, NULL, '', ''),
('test1', '20140701_132836', '', '', NULL, NULL, '', ''),
('test1', '20140701_132841', '', '', NULL, NULL, '', ''),
('test1', '20140701_133013', '', '', NULL, NULL, '', ''),
('test1', '20140701_133019', '', '', NULL, NULL, '', ''),
('test1', '20140701_133629', '', '', NULL, NULL, '', ''),
('test1', '20140701_133639', '', '', NULL, NULL, '', ''),
('test1', '20140701_133643', '', '', NULL, NULL, '', ''),
('test1', '20140701_133810', '', '', NULL, NULL, '', ''),
('test1', '20140702_071117', '', '', NULL, NULL, '', ''),
('test1', '20140702_071123', '', '', NULL, NULL, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE IF NOT EXISTS `User` (
  `username` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `Sex` enum('M','F') NOT NULL,
  `DOB_day` int(30) NOT NULL,
  `DOB_month` int(30) NOT NULL,
  `DOB_year` int(11) NOT NULL,
  `GreetingPicto` varchar(30) NOT NULL,
  `totalNoOfViews` int(30) unsigned NOT NULL,
  `totalNoOfLikes` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `User`
--

INSERT INTO `User` (`username`, `email`, `password`, `Sex`, `DOB_day`, `DOB_month`, `DOB_year`, `GreetingPicto`, `totalNoOfViews`, `totalNoOfLikes`) VALUES
('[test1]', '[test@ps.edu]', '[test1]', '', 0, 0, 0, '', 0, 0),
('test1', 'test@ps.edu', 'test1', '', 0, 0, 0, '', 0, 0),
('', 'arslanshl@gmail.com', 'aaaa', '', 0, 0, 0, '', 0, 0),
('blue345', 'are@a.com', 'aaaa', '', 0, 0, 0, '', 0, 0),
('test1', '20140701_201330', '', '', 0, 0, 0, '', 0, 0),
('hoofar', 'hpourzand@gmail.com', '1000', '', 0, 0, 0, '', 0, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
