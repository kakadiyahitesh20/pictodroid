<?php
echo "<h5>Welcome to PictoLike!</h5>";
?>