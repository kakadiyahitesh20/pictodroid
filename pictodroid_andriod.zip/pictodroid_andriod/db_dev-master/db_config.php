db_config.php
<?php
 
/*
 * All database connection variables
 */
define('DB_USER', "root");
define('DB_PASSWORD', "");
define('DB_DATABASE', "PictoLike");
define('DB_SERVER', "localhost");
?>